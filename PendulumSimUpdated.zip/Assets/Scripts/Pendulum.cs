﻿using UnityEngine;

[DisallowMultipleComponent]
public class Pendulum : MonoBehaviour
{
    [Header("References")]
    public Transform pivot;       // точка крепления
    public Transform bob;         // груз (сфера)
    public LineRenderer stringLR; // Line Renderer для нити (опционально)

    [Header("Parameters")]
    [Tooltip("Длина нити (м)")]
    public float length = 2f;
    [Tooltip("Начальный угол (градусы)")]
    public float initialAngleDeg = 30f;
    [Tooltip("Гравитация (м/с²)")]
    public float gravity = 9.81f;
    [Tooltip("Коэффициент затухания [0..1]")]
    [Range(0f, 1f)]
    public float damping = 0.01f;

    // Внутреннее состояние (runtime)
    [SerializeField] private float angleDeg;              // текущий угол в градусах
    [SerializeField] private float angularVelDegPerSec;   // угловая скорость в град/с
    private bool isRunning = true;

    public float AngleDeg => angleDeg;
    public float PeriodSmallAngle => 2f * Mathf.PI * Mathf.Sqrt(Mathf.Max(length, 0.0001f) / Mathf.Max(gravity, 0.0001f));

    void Start()
    {
        ResetPendulum();
        UpdateVisual();
    }

    void Update()
    {
        if (!isRunning) { UpdateVisual(); return; }

        float dt = Time.deltaTime;

        // Переводим угол в радианы для тригонометрии
        float angleRad = angleDeg * Mathf.Deg2Rad;

        // Ускорение угловое (рад/с^2): θ¨ = - (g / L) * sin(θ)
        float angAccRad = -(gravity / Mathf.Max(length, 0.0001f)) * Mathf.Sin(angleRad);

        // Переводим угловую скорость в радианы, интегрируем, применяем затухание
        float angVelRad = angularVelDegPerSec * Mathf.Deg2Rad;
        angVelRad += angAccRad * dt;
        angVelRad *= (1f - Mathf.Clamp01(damping));

        // Интегрируем угол
        angleRad += angVelRad * dt;

        // Сохраняем обратно в градусы
        angleDeg = angleRad * Mathf.Rad2Deg;
        angularVelDegPerSec = angVelRad * Mathf.Rad2Deg;

        UpdateVisual();
    }

    private void UpdateVisual()
    {
        if (pivot == null || bob == null) return;

        Vector3 offset = new Vector3(
            length * Mathf.Sin(angleDeg * Mathf.Deg2Rad),
            -length * Mathf.Cos(angleDeg * Mathf.Deg2Rad),
            0f
        );

        bob.position = pivot.position + offset;

        if (stringLR != null)
        {
            stringLR.positionCount = 2;
            stringLR.SetPosition(0, pivot.position);
            stringLR.SetPosition(1, bob.position);
        }
    }

    public void ResetPendulum()
    {
        angleDeg = initialAngleDeg;
        angularVelDegPerSec = 0f;
    }

    public void SetRunning(bool run) => isRunning = run;
    public bool ToggleRunning() { isRunning = !isRunning; return isRunning; }

    // Сеттеры для UI
    public void SetLength(float l) => length = Mathf.Max(0.01f, l);
    public void SetInitialAngle(float deg) => initialAngleDeg = deg;
    public void SetAngle(float deg) { angleDeg = deg; angularVelDegPerSec = 0f; }
    public void SetGravity(float g) => gravity = Mathf.Max(0.0001f, g);
    public void SetDamping(float d) => damping = Mathf.Clamp01(d);
}
